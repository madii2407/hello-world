function formvalidatefunc()                                    
{ 
    var nname = document.forms["RegForm"]["name"];  
    var emaill = document.forms["RegForm"]["email"];              
    var pwd = document.forms["RegForm"]["password"];    
    var c_pwd = document.forms["RegForm"]["c_password"]

    if (nname.value == "")                                  
    { 
        window.alert("Please enter your name."); 
        nname.focus(); 
        return false; 
    } 
   
    if (emaill.value == "")                               
    { 
        window.alert("Please enter your email."); 
        emaill.focus(); 
        return false; 
    } 
    
    if (pwd.value == "")                                   
    { 
        window.alert("Please enter a password."); 
        pwd.focus(); 
        return false; 
    } 
	if (c_pwd.value == "")                                   
    { 
        window.alert("Please enter a confirm password."); 
        c_pwd.focus(); 
        return false; 
    } 
	if (c_pwd.value != pwd.value)                                   
    { 
        window.alert("Please enter valid password."); 
        c_pwd.focus(); 
        return false; 
    }

    
	if (emaill.value.indexOf("@", 0) < 0)                 
    { 
        window.alert("Please enter a valid e-mail address."); 
        emaill.focus(); 
        return false; 
    } 
  
	
	if (!validateEmail(emaill.value))                                  
    { 
        window.alert("Please enter valid email."); 
        emaill.focus(); 
        return false; 
    }
   
   
    if (what.selectedIndex < 1)                  
    { 
        alert("Please enter your course."); 
        what.focus(); 
        return false; 
    } 
   
    return true; 
}


function validateEmail(emailll) 
{
    var re = /\S+@\S+/;
    return re.test(emailll);
}