<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="css/style.css">
        <script src="js/main.js"></script>
        <title>Assignment-3</title>
    </head>
<body>
    <div id="topbar">
        <div id="image" class="float-left">
        <img src="images/soundcloud.png" alt="soundcloud" title="soundcloud" height="40px" width="160px">
        </div>
        <div class="float-left title-list">
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">Stream</a></li>
                <li><a href="#">Collection</a></li>
            </ul>
        </div>
       <div id="search-bar" class="float-left" >
            <form>
                <input placeholder="Search for artists, bands, tracks, prodcasts "/>
            </form>
        </div>
        <div class="signin float-right" >
            <button class="first"><a href="Sign.php">Sign in</a></button>
            <button class="second"><a href="CreateAcc.php">Create account</a></button>
        </div>
    </div>