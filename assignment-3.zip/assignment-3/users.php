<?php
require_once ('Connect.php');
if(isset($_POST['insert_user'])){
    $user_name=$_POST["UserName"];
    $user_email=$_POST["Email"];
    $user_pass=$_POST["Password"];
    $user_re_pass=$_POST["ConfirmPassword"];


    $insert_user ="INSERT INTO users (UserName,Email,Password,ConfirmPassword) VALUES ('$user_name','$user_email','$user_pass','$user_re_pass');";
    $insert_user = mysqli_query($con,$insert_user);

    if( $insert_user)
    {
        header("location: ".$_SERVER['PHP_SELF']);
    }

}
