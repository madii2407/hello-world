<div id="footer">
    <p>Legal - Privacy - Cookies - Imprint - Charts - Popular searches</p><br>
    <span>Language:</span>
    <strong>English (US)</strong>
</div>