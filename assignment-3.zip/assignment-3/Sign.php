<?php require("header.php") ?>
<?php
$username = "root";
$password = "";
$hostname = "localhost";

$dbhandle = mysqli_connect($hostname, $username, $password);

if (!$dbhandle) {
    die("Database connection failed: " );
}

$selected = mysqli_select_db($dbhandle,"users");
if (!$selected) {
    die("Database selection failed: " . mysqli_error($dbhandle));
}


$myusername = isset($_POST['Email']) ? $_POST['Email'] : '';
if (isset($_POST['submit'])) {
    echo "Yes, mail is set";
}
$mypassword = isset($_POST['Email']) ? $_POST['Email'] : '';
if (isset($_POST['submit'])) {
    echo "Yes, mail is set";
}

$myusername = stripslashes($myusername);
$mypassword = stripslashes($mypassword);

$query = "SELECT * FROM users WHERE Email='$myusername' and Password='$mypassword';";
$result = mysqli_query($dbhandle,$query);
$count = mysqli_num_rows($result);

mysqli_close($dbhandle);

if($count==1){
    $seconds = 5 + time();
    setcookie(loggedin, date("F jS - g:i a"), $seconds);
    header("location:login_success.php");
}else{
    echo 'Incorrect Username or Password';
}
?>
        <div class="clear">
            <div id="front">
                <strong>Login</strong>
                <form action="Sign.php" method="post">

                    <input class="input"	name="Email" id="userId"  	placeholder="Your email address or profile URL *" type="email"/><br>
                    <input class="input"	name="Password"	id="userId" placeholder="Your password" type="password"/><br>
                    <input class="button" placeholder="" name="" type="submit" value="Continue"/>
                </form>
				
            </div>
        </div>
<?php require("footer.php")?>    
</body>
</html>
                        