<?php require("header.php") ?>
        <div class="clear">
            <div id="front">
                <strong>Sign up</strong>
                <form action="CreateAcc.php" method="post" >
                    <input class="input" name="UserName" id="UserName"   placeholder="Your name" type="name"/><br>
                    <input class="input" name="Email" id="Email" placeholder="Your email" type="email"/><br>
                    <input class="input" name="Password" id="Password" placeholder="Your password" type="password"/><br>
                    <input class="input" name="ConfirmPassword" id="ConfirmPassword" placeholder="Confirm password" type="password"/><br>
                    <input class="button" placeholder="" name="insert_user" type="submit" value="Continue"/>
                </form>
				<?php require("users.php")?>
            </div>
        </div>
	
<?php require("footer.php")?>
</body>
</html>
                        