<header>
  <h2>Cities</h2>
</header>